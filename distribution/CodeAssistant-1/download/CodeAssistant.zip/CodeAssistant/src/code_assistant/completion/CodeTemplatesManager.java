package code_assistant.completion;

import java.awt.event.KeyEvent;
import java.io.File;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import code_assistant.tool.KeyHandler;
import processing.app.Base;
import processing.app.Preferences;
import processing.app.ui.Editor;
import processing.core.PApplet;
import java.io.*;

public class CodeTemplatesManager implements KeyHandler {
	private Editor editor;

	static private final CodeTemplate[] JAVA_DEFAULTS = { new SmartTemplate("sout", "System.out.println();"),
			new SmartTemplate("fori", "for (int i = 0; i < 10; i++) {\n\t\n}"),
			new SmartTemplate("switch", "switch () {\ncase 1:\n\t\n\tbreak;\n}") };

	static private final CodeTemplate[] PRCESSING_DEFAULTS = { new SmartTemplate("setup", "void setup() {\n\t\n}"),
			new SmartTemplate("draw", "void draw() {\n\t\n}"),
			new SmartTemplate("mpress", "void mousePressed() {\n\t\n}"),
			new SmartTemplate("kpress", "void keyPressed() {\n\t\n}") };

	static Map<String, CodeTemplate> templates = new HashMap<>();

	static {
		for (CodeTemplate temp : JAVA_DEFAULTS) {
			templates.put(temp.getKey(), temp);
		}
		for (CodeTemplate temp : PRCESSING_DEFAULTS) {
			templates.put(temp.getKey(), temp);
		}
	}

	public CodeTemplatesManager(Editor editor) {
		this.editor = editor;

		File tools = Base.getSketchbookToolsFolder();		
		println("tools: " + tools + " - " + tools.exists());		
	}

	@Override
	public boolean handlePressed(KeyEvent e) {
		int key = e.getKeyCode();

		if (e.isControlDown() && key == KeyEvent.VK_SPACE) {

			String trigger = checkTrigger();

			if (templates.containsKey(trigger)) {

				int triggerEnd = editor.getCaretOffset();
				int triggerStart = triggerEnd - trigger.length();
				editor.setSelection(triggerStart, triggerEnd);

				editor.setSelectedText(templates.get(trigger).getCode());
				int caret = editor.getCaretOffset() - templates.get(trigger).getCaretOffset();
				editor.setSelection(caret, caret);
			}

		}
		return false;
	}

	@Override
	public boolean handleTyped(KeyEvent e) {
		return false;
	}

	private String checkTrigger() {
		int line = editor.getTextArea().getCaretLine();
		String lineText = editor.getLineText(line);

		StringBuilder sb = new StringBuilder();
		int index = getPositionInsideLine() - 1;

		while (index >= 0) {
			char ch = lineText.charAt(index);

			if (Character.isWhitespace(ch)) {
				break;
			}
			sb.append(ch);
			index--;
		}
		return sb.reverse().toString();
	}

	private int getPositionInsideLine() {
		int caretOffset = editor.getCaretOffset();
		int lineStartOffset = editor.getLineStartOffset(editor.getTextArea().getCaretLine());
		return caretOffset - lineStartOffset;
	}

	private void println(Object... what) {
		for (Object s : what) {
			System.out.println(s.toString());
		}
	}

}
