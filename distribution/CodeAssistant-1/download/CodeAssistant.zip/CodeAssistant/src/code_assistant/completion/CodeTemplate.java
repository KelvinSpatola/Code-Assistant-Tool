package code_assistant.completion;

import java.util.HashMap;
import java.util.Map;

public abstract class CodeTemplate {
	protected String key;
	protected String code;
	protected int caret;
	
	protected Map<String, String> placeholders= new HashMap<>();

	// CONSTRUCTORS	
	
	public CodeTemplate() {
	}
	
	public CodeTemplate(String key, String code) {
		this.key = key;
		this.code = code;
		this.caret = caret;
	}
	
	protected abstract String parse();
	
	public String getKey() {
		return key;
	}

	public String getCode() {
		return code;
	}
	
	public int getCaretOffset() {
		return caret;
	}
	
	
}
