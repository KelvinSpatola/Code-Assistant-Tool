package code_assistant.completion;

public class SmartTemplate extends CodeTemplate {
	
	public SmartTemplate(String key, String code) {
		super(key, code);
	}

	@Override
	protected String parse() {
		// TODO Auto-generated method stub
		return null;
	}

}
