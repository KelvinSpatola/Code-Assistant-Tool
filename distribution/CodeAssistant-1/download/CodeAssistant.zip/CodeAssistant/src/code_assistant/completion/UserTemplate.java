package code_assistant.completion;

public class UserTemplate extends CodeTemplate {

	@Override
	protected String parse() {
		// TODO Auto-generated method stub
		return null;
	}

}
