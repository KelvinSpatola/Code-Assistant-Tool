package code_assistant.tool;

import java.awt.event.KeyEvent;

public interface KeyPressedListener {
	boolean handlePressed(KeyEvent e);
}
